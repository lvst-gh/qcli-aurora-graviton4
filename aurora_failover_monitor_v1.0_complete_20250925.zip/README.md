# Aurora Failover Monitor

Aurora节点切换过程监控和分析工具，通过MySQL和DNS双探针高频监控来分析切换过程中的行为变化。

## 功能特性

- **MySQL探针**: 执行心跳表操作，监控数据库连接和响应时间
- **DNS探针**: 监控Aurora集群端点的DNS解析变化
- **性能基线**: 自动建立性能基线，识别异常响应时间
- **超时控制**: 基于基线的2倍时间进行超时控制
- **多进程架构**: MySQL和DNS探针独立运行，互不影响
- **高频监控**: 500ms间隔监控，捕获切换过程细节
- **详细日志**: JSON格式日志，便于后续分析

## 环境要求

- Python 3.8+
- 新加坡区域的EC2实例（堡垒机）
- Aurora MySQL 3.10集群
- 必要的AWS权限

## 安装步骤

### 1. 部署Aurora集群

```bash
# 在本地运行，部署测试集群
python deploy_aurora_cluster.py
```

这将创建：
- Aurora MySQL 3.10集群
- 两个r7g.2xlarge实例在同一AZ
- 必要的安全组和子网组
- 生成配置文件

### 2. 在堡垒机上安装依赖

```bash
# SSH到堡垒机
ssh -i ~/Documents/VSCodeFolder/_aihome/kp-sin.pem ec2-user@54.255.54.192

# 安装Python依赖
pip3 install -r requirements.txt

# 或者单独安装
pip3 install pymysql pandas matplotlib seaborn boto3
```

### 3. 上传监控脚本

```bash
# 从本地上传文件到堡垒机
scp -i ~/Documents/VSCodeFolder/_aihome/kp-sin.pem aurora_failover_monitor.py ec2-user@54.255.54.192:~/
scp -i ~/Documents/VSCodeFolder/_aihome/kp-sin.pem analyze_failover.py ec2-user@54.255.54.192:~/
scp -i ~/Documents/VSCodeFolder/_aihome/kp-sin.pem aurora_config.json ec2-user@54.255.54.192:~/
```

## 使用方法

### 1. 启动监控

```bash
# 在堡垒机上运行
python3 aurora_failover_monitor.py
```

监控启动后会：
- 建立MySQL和DNS性能基线
- 开始高频监控（500ms间隔）
- 实时显示监控状态
- 记录详细日志到文件

### 2. 执行切换测试

在另一个终端执行手动切换：

```bash
# 手动触发Aurora集群切换
aws rds failover-db-cluster \
  --db-cluster-identifier aurora-failover-test \
  --region ap-southeast-1
```

### 3. 停止监控

按 `Ctrl+C` 停止监控程序。

### 4. 分析结果

```bash
# 分析监控日志
python3 analyze_failover.py aurora_probe_20250918.jsonl
```

分析脚本会生成：
- 详细的文本分析报告
- 时间线图表（PNG格式）
- 切换事件统计
- 性能变化分析
- DNS解析变化分析

## 日志格式

监控产生两种日志文件：

### 1. 结构化日志 (*.jsonl)
```json
{
  "timestamp": "2025-09-18T08:30:15.123456",
  "type": "mysql",
  "status": "success",
  "elapsed_ms": 45.67,
  "baseline_ms": 50.0,
  "is_slow": false,
  "result": 1
}
```

### 2. 运行日志 (*.log)
```
2025-09-18 08:30:15.123 - INFO - MySQL: 45.67ms
2025-09-18 08:30:15.623 - INFO - DNS: 12.34ms
2025-09-18 08:30:16.123 - ERROR - MySQL ERROR: Connection refused
```

## 监控指标

### MySQL探针
- 连接建立时间
- 心跳表创建/插入/查询
- 事务提交时间
- 错误和超时检测

### DNS探针
- DNS解析时间
- 解析IP地址变化
- 解析失败检测
- IP地址跳动分析

## 分析维度

### 时间维度
- 切换前后的性能对比
- 错误持续时间分析
- 恢复时间测量

### 行为维度
- DNS解析IP变化模式
- 数据库连接中断模式
- 应用层感知延迟

### 性能维度
- 响应时间分布变化
- 慢查询识别
- 基线偏差分析

## 注意事项

1. **网络延迟**: 确保Aurora实例与EC2在同一AZ以减少网络影响
2. **监控频率**: 500ms间隔可能产生大量日志，注意磁盘空间
3. **超时设置**: 基于基线的2倍时间，可根据需要调整
4. **权限要求**: 确保EC2有访问Aurora的网络权限
5. **资源消耗**: 高频监控会消耗一定的CPU和网络资源

## 故障排除

### 连接问题
```bash
# 测试数据库连接
mysql -h aurora-cluster-endpoint.cluster-xxx.ap-southeast-1.rds.amazonaws.com -u admin -p

# 测试DNS解析
dig aurora-cluster-endpoint.cluster-xxx.ap-southeast-1.rds.amazonaws.com
```

### 权限问题
```bash
# 检查安全组规则
aws ec2 describe-security-groups --group-ids sg-xxx --region ap-southeast-1

# 检查子网路由
aws ec2 describe-route-tables --region ap-southeast-1
```

## 清理资源

测试完成后清理AWS资源：

```bash
# 删除Aurora集群（先删除实例）
aws rds delete-db-instance --db-instance-identifier aurora-failover-test-writer --skip-final-snapshot --region ap-southeast-1
aws rds delete-db-instance --db-instance-identifier aurora-failover-test-reader --skip-final-snapshot --region ap-southeast-1

# 删除集群
aws rds delete-db-cluster --db-cluster-identifier aurora-failover-test --skip-final-snapshot --region ap-southeast-1

# 删除子网组和安全组
aws rds delete-db-subnet-group --db-subnet-group-name aurora-test-subnet-group --region ap-southeast-1
aws ec2 delete-security-group --group-id sg-xxx --region ap-southeast-1
```
