# Aurora切换监控系统 - 完整使用指南

## 📋 系统概述

Aurora切换监控系统是一个用于测试和分析Amazon Aurora数据库集群故障切换过程的工具。它通过高频监控MySQL连接和DNS解析，精确捕获切换过程中的性能变化和中断时间。

## 🎯 测试目标

- **监控Aurora集群切换过程**：自动触发切换并监控整个过程
- **分析性能影响**：测量读写操作的中断时间和性能变化
- **DNS切换检测**：监控集群端点的DNS解析和IP变化
- **生成详细报告**：自动生成包含图表和分析的HTML报告

## 🛠️ 环境要求

### AWS环境
- **Aurora集群**：MySQL 3.10版本，至少2个实例
- **EC2堡垒机**：与Aurora集群在同一VPC和AZ
- **网络权限**：EC2能访问Aurora集群的3306端口
- **AWS CLI权限**：能执行`rds:FailoverDBCluster`操作

### 软件要求
- **Python 3.8+**
- **必要的Python包**：pymysql, boto3
- **AWS CLI**：已配置访问权限

## 📦 快速开始

### 步骤1：下载和解压代码
```bash
# 下载代码包
wget https://your-domain/aurora_failover_monitor_v1.0_20250925.zip

# 解压到工作目录
unzip aurora_failover_monitor_v1.0_20250925.zip
cd aurora_failover_monitor/
```

### 步骤2：安装依赖
```bash
# 安装Python依赖
pip3 install -r requirements.txt

# 或者手动安装
pip3 install pymysql boto3
```

### 步骤3：配置Aurora集群信息
编辑 `aurora_config.json` 文件：

```json
{
    "cluster_endpoint": "your-cluster.cluster-xxxxx.region.rds.amazonaws.com",
    "username": "admin",
    "password": "your-password",
    "database": "test",
    "cluster_name": "your-cluster-name",
    "region": "ap-southeast-1"
}
```

**配置说明**：
- `cluster_endpoint`：Aurora集群的写入端点
- `username/password`：数据库用户名和密码
- `database`：测试用的数据库名（会自动创建）
- `cluster_name`：用于AWS CLI切换命令的集群标识符
- `region`：AWS区域

### 步骤4：验证连接
```bash
# 测试数据库连接
mysql -h your-cluster.cluster-xxxxx.region.rds.amazonaws.com -u admin -p

# 测试DNS解析
dig your-cluster.cluster-xxxxx.region.rds.amazonaws.com

# 测试AWS CLI权限
aws rds describe-db-clusters --db-cluster-identifier your-cluster-name --region ap-southeast-1
```

### 步骤5：运行监控测试
```bash
# 启动监控程序
python3 aurora_failover_monitor.py
```

**测试流程**：
1. **预热阶段**（15秒）：建立性能基线
2. **切换触发**：自动执行Aurora集群切换
3. **监控阶段**（45秒）：捕获切换过程和恢复
4. **自动停止**：保存数据并提示生成报告

### 步骤6：生成分析报告
```bash
# 生成HTML报告（程序结束后会提示具体命令）
python3 generate_aurora_report.py aurora_probe_YYYYMMDD_HHMMSS.jsonl
```

## 📊 输出文件说明

### 监控数据文件
- **格式**：`aurora_probe_YYYYMMDD_HHMMSS.jsonl`
- **内容**：JSON Lines格式的原始监控数据
- **包含**：MySQL读写状态、DNS解析结果、切换事件

### HTML分析报告
- **格式**：`aurora_probe_YYYYMMDD_HHMMSS_standard_report.html`
- **内容**：完整的可视化分析报告
- **包含**：
  - 📈 时间序列图表（响应时间变化）
  - 📋 详细事件时间表
  - 💡 关键发现和性能分析
  - 🔍 切换过程详细分析

## 🔧 常见问题排查

### 连接问题
```bash
# 问题：无法连接到Aurora集群
# 解决：检查安全组和网络配置
aws ec2 describe-security-groups --group-ids sg-xxxxx

# 问题：DNS解析失败
# 解决：检查VPC DNS设置和路由表
dig @8.8.8.8 your-cluster-endpoint
```

### 权限问题
```bash
# 问题：无法执行切换命令
# 解决：检查IAM权限
aws sts get-caller-identity
aws iam get-user

# 需要的权限：
# - rds:FailoverDBCluster
# - rds:DescribeDBClusters
```

### 程序运行问题
```bash
# 问题：Python包缺失
# 解决：重新安装依赖
pip3 install --upgrade pymysql boto3

# 问题：配置文件错误
# 解决：验证JSON格式
python3 -c "import json; print(json.load(open('aurora_config.json')))"
```

## ⚙️ 高级配置

### 自定义监控参数
在 `aurora_failover_monitor.py` 中可以调整：

```python
# 监控间隔（默认500ms）
probe_interval = 0.5

# 性能基线（默认值）
mysql_read_baseline = 50.0    # MySQL读基线(ms)
mysql_write_baseline = 100.0  # MySQL写基线(ms)
dns_baseline = 100.0          # DNS基线(ms)

# 测试时长
warmup_time = 15      # 预热时间(秒)
monitor_time = 45     # 切换后监控时间(秒)
```

### 多集群测试
```bash
# 为不同集群创建不同的配置文件
cp aurora_config.json aurora_config_prod.json
cp aurora_config.json aurora_config_test.json

# 使用不同配置运行测试
# 需要修改程序中的配置文件路径
```

## 📈 结果解读

### 关键指标
- **切换触发时间**：Aurora切换命令执行的时间点
- **写操作中断时间**：写操作不可用的持续时间
- **读操作中断时间**：读操作不可用的持续时间
- **DNS切换时间**：集群端点IP地址变化的时间点
- **性能恢复时间**：服务完全恢复正常的时间

### 中断模式分析
1. **连接拒绝阶段**：数据库完全不可用
2. **只读模式阶段**：只能执行读操作
3. **完全恢复阶段**：读写操作都正常

### 性能对比
- **切换前后延迟对比**：分析性能变化趋势
- **基线偏差分析**：识别异常响应时间
- **IP切换分析**：DNS解析变化模式

## 🚀 生产环境使用建议

### 测试时机
- **维护窗口期**：避免影响业务
- **低峰时段**：减少对用户的影响
- **定期测试**：建立切换性能基线

### 安全考虑
- **只读用户**：使用只读权限的数据库用户
- **测试数据库**：避免在生产数据库上测试
- **网络隔离**：确保测试流量不影响生产

### 监控集成
- **告警系统**：集成到现有监控系统
- **自动化**：结合CI/CD流程定期执行
- **报告存储**：保存历史测试结果用于趋势分析

## 📞 技术支持

### 日志分析
```bash
# 查看详细错误信息
tail -f aurora_monitor_*.log

# 分析JSON数据
jq '.' aurora_probe_*.jsonl | head -20
```

### 性能调优
- **网络延迟**：确保EC2与Aurora在同一AZ
- **监控频率**：根据需要调整探针间隔
- **资源使用**：监控CPU和内存使用情况

### 故障排除流程
1. **验证环境**：检查网络、权限、配置
2. **测试连接**：单独测试MySQL和DNS连接
3. **查看日志**：分析错误信息和异常
4. **逐步调试**：从简单测试开始排查

---

## 📝 版本信息
- **版本**：v1.0
- **发布日期**：2025-09-25
- **兼容性**：Aurora MySQL 3.10+, Python 3.8+
- **测试环境**：AWS ap-southeast-1 区域

## 🤝 贡献和反馈
如有问题或建议，请通过以下方式联系：
- 创建Issue报告问题
- 提交Pull Request改进代码
- 分享使用经验和最佳实践
