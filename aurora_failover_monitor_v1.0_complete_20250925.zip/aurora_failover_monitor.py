#!/usr/bin/env python3
"""
Aurora Failover Monitor - Final Version
Aurora集群切换监控工具，通过MySQL读写操作和DNS解析监控切换过程
"""

import json
import time
import pymysql
import subprocess
import threading
import multiprocessing
import signal
import sys
import os
from datetime import datetime, timedelta
import boto3
from botocore.exceptions import ClientError

def get_timestamp_100ms():
    """获取精确到100ms的时间戳"""
    now = datetime.now()
    # 将微秒四舍五入到最近的100ms
    microseconds = now.microsecond
    rounded_microseconds = round(microseconds / 100000) * 100000
    if rounded_microseconds >= 1000000:
        rounded_microseconds = 0
        now = now + timedelta(seconds=1)
    return now.replace(microsecond=rounded_microseconds).isoformat()

class AuroraFailoverMonitor:
    def __init__(self, config):
        self.config = config
        # 从配置文件读取基线值
        baselines = config.get('baselines', {})
        self.mysql_read_baseline = baselines.get('mysql_read_ms', 50.0)
        self.mysql_write_baseline = baselines.get('mysql_write_ms', 100.0)
        self.dns_baseline = baselines.get('dns_ms', 100.0)
        
        # 从配置文件读取超时值
        timeouts = config.get('timeouts', {})
        self.mysql_read_timeout = timeouts.get('mysql_read_ms', 100) / 1000.0
        self.mysql_write_timeout = timeouts.get('mysql_write_ms', 200) / 1000.0
        self.dns_timeout = timeouts.get('dns_ms', 200) / 1000.0
        self.dns_command_timeout = timeouts.get('dns_command_sec', 0.2)
        
        self.probe_interval = config.get('probe_interval', 0.5)
        
        # 生成带时间戳的文件名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.jsonl_file = f"aurora_probe_{timestamp}.jsonl"
        
        # 多进程控制
        self.stop_event = multiprocessing.Event()
        self.processes = []
        
        # AWS客户端
        self.rds_client = boto3.client('rds', region_name=config['aws']['region'])
        self.cluster_name = config['aws']['cluster_name']
        
        print(f"监控配置:")
        print(f"  MySQL读基线: {self.mysql_read_baseline}ms")
        print(f"  MySQL写基线: {self.mysql_write_baseline}ms") 
        print(f"  DNS基线: {self.dns_baseline}ms")
        print(f"  探针间隔: {self.probe_interval}s")
        print(f"  数据文件: {self.jsonl_file}")

    def write_event(self, event_data):
        """写入事件到JSONL文件"""
        try:
            with open(self.jsonl_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(event_data, ensure_ascii=False) + '\n')
                f.flush()
        except Exception as e:
            print(f"写入文件错误: {e}")

    def mysql_read_probe(self):
        """MySQL读操作探针"""
        try:
            start_time = time.time()
            connection = pymysql.connect(
                host=self.config['mysql']['host'],
                user=self.config['mysql']['user'],
                password=self.config['mysql']['password'],
                database=self.config['mysql']['database'],
                connect_timeout=self.mysql_read_timeout,
                read_timeout=self.mysql_read_timeout,
                write_timeout=self.mysql_read_timeout
            )
            
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
                result = cursor.fetchone()
            
            connection.close()
            elapsed_ms = (time.time() - start_time) * 1000
            
            return {
                'status': 'success',
                'elapsed_ms': round(elapsed_ms, 2),
                'baseline_ms': self.mysql_read_baseline,
                'is_slow': elapsed_ms > self.mysql_read_baseline * 2,
                'result': result[0] if result else None
            }
            
        except Exception as e:
            elapsed_ms = (time.time() - start_time) * 1000
            return {
                'status': 'error',
                'elapsed_ms': round(elapsed_ms, 2),
                'baseline_ms': self.mysql_read_baseline,
                'is_slow': True,
                'error': str(e)
            }

    def mysql_write_probe(self):
        """MySQL写操作探针"""
        try:
            start_time = time.time()
            connection = pymysql.connect(
                host=self.config['mysql']['host'],
                user=self.config['mysql']['user'],
                password=self.config['mysql']['password'],
                database=self.config['mysql']['database'],
                connect_timeout=self.mysql_write_timeout,
                read_timeout=self.mysql_write_timeout,
                write_timeout=self.mysql_write_timeout
            )
            
            with connection.cursor() as cursor:
                # 创建心跳表（如果不存在）
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS heartbeat (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # 插入心跳记录
                cursor.execute("INSERT INTO heartbeat () VALUES ()")
                
                # 提交事务
                connection.commit()
                
                # 获取插入的记录ID
                record_id = cursor.lastrowid
                
                # 验证插入
                cursor.execute("SELECT COUNT(*) FROM heartbeat WHERE id = %s", (record_id,))
                result = cursor.fetchone()
            
            connection.close()
            elapsed_ms = (time.time() - start_time) * 1000
            
            return {
                'status': 'success',
                'elapsed_ms': round(elapsed_ms, 2),
                'baseline_ms': self.mysql_write_baseline,
                'is_slow': elapsed_ms > self.mysql_write_baseline * 2,
                'record_id': record_id,
                'verified': result[0] == 1 if result else False
            }
            
        except Exception as e:
            elapsed_ms = (time.time() - start_time) * 1000
            return {
                'status': 'error',
                'elapsed_ms': round(elapsed_ms, 2),
                'baseline_ms': self.mysql_write_baseline,
                'is_slow': True,
                'error': str(e)
            }

    def dns_probe(self):
        """DNS解析探针"""
        try:
            start_time = time.time()
            
            # 使用dig命令进行DNS查询
            cmd = ['dig', '+short', '+time=1', '+tries=1', self.config['dns']['endpoint']]
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.dns_command_timeout
            )
            
            elapsed_ms = (time.time() - start_time) * 1000
            
            if result.returncode == 0 and result.stdout.strip():
                ips = [ip.strip() for ip in result.stdout.strip().split('\n') if ip.strip()]
                return {
                    'status': 'success',
                    'elapsed_ms': round(elapsed_ms, 2),
                    'baseline_ms': self.dns_baseline,
                    'is_slow': elapsed_ms > self.dns_baseline * 2,
                    'ips': ips,
                    'ip_count': len(ips)
                }
            else:
                return {
                    'status': 'error',
                    'elapsed_ms': round(elapsed_ms, 2),
                    'baseline_ms': self.dns_baseline,
                    'is_slow': True,
                    'error': f"DNS查询失败: {result.stderr.strip()}"
                }
                
        except subprocess.TimeoutExpired:
            elapsed_ms = (time.time() - start_time) * 1000
            return {
                'status': 'error',
                'elapsed_ms': round(elapsed_ms, 2),
                'baseline_ms': self.dns_baseline,
                'is_slow': True,
                'error': 'DNS查询超时'
            }
        except Exception as e:
            elapsed_ms = (time.time() - start_time) * 1000
            return {
                'status': 'error',
                'elapsed_ms': round(elapsed_ms, 2),
                'baseline_ms': self.dns_baseline,
                'is_slow': True,
                'error': str(e)
            }

    def trigger_failover(self):
        """触发Aurora集群切换"""
        try:
            print(f"\n🔄 触发Aurora集群切换: {self.cluster_name}")
            
            response = self.rds_client.failover_db_cluster(
                DBClusterIdentifier=self.cluster_name
            )
            
            # 记录切换事件
            event_data = {
                'timestamp': get_timestamp_100ms(),
                'type': 'failover_event',
                'status': 'triggered',
                'cluster_name': self.cluster_name,
                'aws_response': {
                    'cluster_id': response['DBCluster']['DBClusterIdentifier'],
                    'status': response['DBCluster']['Status'],
                    'engine': response['DBCluster']['Engine']
                }
            }
            self.write_event(event_data)
            
            print(f"✅ 切换命令已发送")
            print(f"   集群状态: {response['DBCluster']['Status']}")
            return True
            
        except ClientError as e:
            error_msg = f"AWS API错误: {e.response['Error']['Code']} - {e.response['Error']['Message']}"
            print(f"❌ 切换失败: {error_msg}")
            
            # 记录错误事件
            event_data = {
                'timestamp': get_timestamp_100ms(),
                'type': 'failover_event',
                'status': 'error',
                'cluster_name': self.cluster_name,
                'error': error_msg
            }
            self.write_event(event_data)
            return False
            
        except Exception as e:
            error_msg = str(e)
            print(f"❌ 切换失败: {error_msg}")
            
            # 记录错误事件
            event_data = {
                'timestamp': get_timestamp_100ms(),
                'type': 'failover_event',
                'status': 'error',
                'cluster_name': self.cluster_name,
                'error': error_msg
            }
            self.write_event(event_data)
            return False

def mysql_read_probe_worker(config, jsonl_file, stop_event, probe_interval):
    """MySQL读探针工作进程"""
    monitor = AuroraFailoverMonitor(config)
    
    while not stop_event.is_set():
        try:
            timestamp = get_timestamp_100ms()
            result = monitor.mysql_read_probe()
            
            event_data = {
                'timestamp': timestamp,
                'type': 'mysql_read',
                'status': 'read_success' if result['status'] == 'success' else 'read_error',
                **{k: v for k, v in result.items() if k != 'status'}
            }
            
            monitor.write_event(event_data)
            
            # 控制台输出
            if result['status'] == 'success':
                status_icon = "🐌" if result['is_slow'] else "✅"
                print(f"{status_icon} MySQL读: {result['elapsed_ms']:.1f}ms")
            else:
                print(f"❌ MySQL读错误: {result.get('error', 'Unknown')}")
            
            time.sleep(probe_interval)
            
        except Exception as e:
            print(f"MySQL读探针异常: {e}")
            time.sleep(probe_interval)

def mysql_write_probe_worker(config, jsonl_file, stop_event, probe_interval):
    """MySQL写探针工作进程"""
    monitor = AuroraFailoverMonitor(config)
    
    while not stop_event.is_set():
        try:
            timestamp = get_timestamp_100ms()
            result = monitor.mysql_write_probe()
            
            event_data = {
                'timestamp': timestamp,
                'type': 'mysql_write',
                'status': 'write_success' if result['status'] == 'success' else 'write_error',
                **{k: v for k, v in result.items() if k != 'status'}
            }
            
            monitor.write_event(event_data)
            
            # 控制台输出
            if result['status'] == 'success':
                status_icon = "🐌" if result['is_slow'] else "✅"
                verified_icon = "✓" if result.get('verified', False) else "?"
                print(f"{status_icon} MySQL写: {result['elapsed_ms']:.1f}ms {verified_icon}")
            else:
                print(f"❌ MySQL写错误: {result.get('error', 'Unknown')}")
            
            time.sleep(probe_interval)
            
        except Exception as e:
            print(f"MySQL写探针异常: {e}")
            time.sleep(probe_interval)

def dns_probe_worker(config, jsonl_file, stop_event, probe_interval):
    """DNS探针工作进程"""
    monitor = AuroraFailoverMonitor(config)
    
    while not stop_event.is_set():
        try:
            timestamp = get_timestamp_100ms()
            result = monitor.dns_probe()
            
            event_data = {
                'timestamp': timestamp,
                'type': 'dns',
                'status': 'dns_success' if result['status'] == 'success' else 'dns_error',
                'resolved_ips': result.get('ips', []) if result['status'] == 'success' else [],
                **{k: v for k, v in result.items() if k not in ['status', 'ips']}
            }
            
            monitor.write_event(event_data)
            
            # 控制台输出
            if result['status'] == 'success':
                status_icon = "🐌" if result['is_slow'] else "✅"
                ip_info = f"({result['ip_count']}个IP)" if 'ip_count' in result else ""
                print(f"{status_icon} DNS: {result['elapsed_ms']:.1f}ms {ip_info}")
            else:
                print(f"❌ DNS错误: {result.get('error', 'Unknown')}")
            
            time.sleep(probe_interval)
            
        except Exception as e:
            print(f"DNS探针异常: {e}")
            time.sleep(probe_interval)

def signal_handler(signum, frame):
    """信号处理器"""
    print(f"\n🛑 收到信号 {signum}，正在停止监控...")
    sys.exit(0)

def main():
    # 注册信号处理器
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # 加载配置
    try:
        with open('aurora_config.json', 'r', encoding='utf-8') as f:
            config = json.load(f)
    except FileNotFoundError:
        print("❌ 配置文件 aurora_config.json 不存在")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"❌ 配置文件格式错误: {e}")
        sys.exit(1)
    
    print("🚀 Aurora切换监控系统启动")
    print("=" * 50)
    
    monitor = AuroraFailoverMonitor(config)
    
    try:
        # 阶段1: 探针预热 (15秒)
        print(f"\n📊 阶段1: 探针预热 (15秒)")
        print("建立性能基线，准备监控环境...")
        
        # 启动探针进程
        processes = []
        
        # MySQL读探针
        p1 = multiprocessing.Process(
            target=mysql_read_probe_worker,
            args=(config, monitor.jsonl_file, monitor.stop_event, monitor.probe_interval)
        )
        p1.start()
        processes.append(p1)
        
        # MySQL写探针
        p2 = multiprocessing.Process(
            target=mysql_write_probe_worker,
            args=(config, monitor.jsonl_file, monitor.stop_event, monitor.probe_interval)
        )
        p2.start()
        processes.append(p2)
        
        # DNS探针
        p3 = multiprocessing.Process(
            target=dns_probe_worker,
            args=(config, monitor.jsonl_file, monitor.stop_event, monitor.probe_interval)
        )
        p3.start()
        processes.append(p3)
        
        # 预热阶段
        time.sleep(15)
        
        # 阶段2: 触发切换
        print(f"\n🔄 阶段2: 触发Aurora节点切换")
        failover_success = monitor.trigger_failover()
        
        if not failover_success:
            print("❌ 切换触发失败，但继续监控...")
        
        # 阶段3: 切换后监控 (45秒)
        print(f"\n📈 阶段3: 切换后监控 (45秒)")
        print("监控切换过程和恢复情况...")
        time.sleep(45)
        
        # 阶段4: 停止监控
        print(f"\n🏁 阶段4: 停止监控")
        print("正在停止所有探针进程...")
        
        # 停止所有进程
        monitor.stop_event.set()
        
        for p in processes:
            p.join(timeout=5)
            if p.is_alive():
                p.terminate()
                p.join(timeout=2)
                if p.is_alive():
                    p.kill()
        
        print(f"✅ 监控完成！数据已保存到: {monitor.jsonl_file}")
        print(f"📊 请使用以下命令生成分析报告:")
        print(f"   python3 generate_aurora_report.py {monitor.jsonl_file}")
        
    except KeyboardInterrupt:
        print(f"\n🛑 用户中断，正在停止监控...")
        monitor.stop_event.set()
        
        for p in processes:
            p.terminate()
            p.join(timeout=2)
            if p.is_alive():
                p.kill()
        
        print(f"✅ 监控已停止！数据已保存到: {monitor.jsonl_file}")
        
    except Exception as e:
        print(f"❌ 监控过程中发生错误: {e}")
        monitor.stop_event.set()
        
        for p in processes:
            p.terminate()
            p.join(timeout=2)
            if p.is_alive():
                p.kill()

if __name__ == "__main__":
    main()
