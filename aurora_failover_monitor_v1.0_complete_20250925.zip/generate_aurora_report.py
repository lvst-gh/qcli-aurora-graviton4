#!/usr/bin/env python3
"""
基于参考模板生成Aurora切换标准分析报告
"""

import json
import sys
from datetime import datetime
from collections import defaultdict

def load_jsonl_data(file_path):
    """加载JSONL监控数据"""
    events = []
    with open(file_path, 'r') as f:
        for line in f:
            if line.strip():
                try:
                    events.append(json.loads(line.strip()))
                except:
                    continue
    return events

def analyze_test_data(events):
    """分析测试数据"""
    # 分类事件
    mysql_read_events = [e for e in events if e.get('type') == 'mysql_read']
    mysql_write_events = [e for e in events if e.get('type') == 'mysql_write']
    dns_events = [e for e in events if e.get('type') == 'dns']
    failover_events = [e for e in events if e.get('type') == 'failover_event']
    
    # 时间分析
    if events:
        start_time = min(events, key=lambda x: x['timestamp'])['timestamp']
        end_time = max(events, key=lambda x: x['timestamp'])['timestamp']
        
        start_dt = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(end_time.replace('Z', '+00:00'))
        duration = int((end_dt - start_dt).total_seconds())
    else:
        start_time = end_time = ""
        duration = 0
    
    # 切换时间
    failover_time = ""
    failover_time_str = ""
    if failover_events:
        failover_time = failover_events[0]['timestamp']
        try:
            failover_dt = datetime.fromisoformat(failover_time.replace('Z', '+00:00'))
            failover_time_str = failover_dt.strftime('%H:%M:%S')
        except:
            failover_time_str = ""
    
    # 找到DNS切换时间（IP地址变化的时间点）
    dns_switch_time = ""
    dns_switch_time_str = ""
    prev_ip = None
    for event in dns_events:
        if event.get('status') == 'dns_success':
            ips = event.get('resolved_ips', [])
            current_ip = ips[2] if len(ips) > 2 else None
            if prev_ip and current_ip and prev_ip != current_ip:
                dns_switch_time = event['timestamp']
                try:
                    dns_dt = datetime.fromisoformat(dns_switch_time.replace('Z', '+00:00'))
                    dns_switch_time_str = dns_dt.strftime('%H:%M:%S')
                except:
                    dns_switch_time_str = ""
                break
            prev_ip = current_ip
    
    # 错误分析
    read_errors = [e for e in mysql_read_events if 'error' in e]
    write_errors = [e for e in mysql_write_events if 'error' in e]
    
    # 计算中断时间
    if read_errors:
        first_read_error = min(read_errors, key=lambda x: x['timestamp'])['timestamp']
        last_read_error = max(read_errors, key=lambda x: x['timestamp'])['timestamp']
        
        first_dt = datetime.fromisoformat(first_read_error.replace('Z', '+00:00'))
        last_dt = datetime.fromisoformat(last_read_error.replace('Z', '+00:00'))
        read_outage = int((last_dt - first_dt).total_seconds()) + 1
    else:
        read_outage = 0
    
    if write_errors:
        first_write_error = min(write_errors, key=lambda x: x['timestamp'])['timestamp']
        last_write_error = max(write_errors, key=lambda x: x['timestamp'])['timestamp']
        
        first_dt = datetime.fromisoformat(first_write_error.replace('Z', '+00:00'))
        last_dt = datetime.fromisoformat(last_write_error.replace('Z', '+00:00'))
        write_outage = int((last_dt - first_dt).total_seconds()) + 1
    else:
        write_outage = 0
    
    total_outage = max(read_outage, write_outage)
    
    return {
        'start_time': start_time,
        'end_time': end_time,
        'duration': duration,
        'failover_time': failover_time,
        'failover_time_str': failover_time_str,
        'dns_switch_time': dns_switch_time,
        'dns_switch_time_str': dns_switch_time_str,
        'total_events': len(events),
        'mysql_read_count': len(mysql_read_events),
        'mysql_write_count': len(mysql_write_events),
        'dns_count': len(dns_events),
        'read_errors': len(read_errors),
        'write_errors': len(write_errors),
        'read_outage': read_outage,
        'write_outage': write_outage,
        'total_outage': total_outage,
        'events': events
    }

def generate_chart_data(events):
    """生成图表数据"""
    # 按时间分组所有事件
    time_data = {}
    
    for event in events:
        try:
            dt = datetime.fromisoformat(event['timestamp'].replace('Z', '+00:00'))
            time_str = dt.strftime('%H:%M:%S')
            
            if time_str not in time_data:
                time_data[time_str] = {'dns': None, 'read': None, 'write': None}
            
            if event.get('type') == 'dns':
                status = 1 if event.get('status') == 'dns_success' else 0
                time_data[time_str]['dns'] = status
            elif event.get('type') == 'mysql_read':
                status = 1 if event.get('status') == 'read_success' else 0
                time_data[time_str]['read'] = status
            elif event.get('type') == 'mysql_write':
                status = 1 if event.get('status') == 'write_success' else 0
                time_data[time_str]['write'] = status
        except:
            continue
    
    # 转换为ECharts需要的格式
    sorted_times = sorted(time_data.keys())
    chart_data = {
        'times': sorted_times,
        'dnsStatus': [time_data[t]['dns'] for t in sorted_times],
        'readStatus': [time_data[t]['read'] for t in sorted_times],
        'writeStatus': [time_data[t]['write'] for t in sorted_times]
    }
    
    return chart_data

def generate_event_table_data(events):
    """生成事件表格数据"""
    # 按时间分组事件
    time_groups = defaultdict(lambda: {'dns': '', 'read': '', 'write': '', 'main': ''})
    
    # 分析关键时间点
    failover_time = None
    dns_switch_time = None
    first_error_time = None
    readonly_start_time = None
    recovery_time = None
    
    # 找到关键时间点
    prev_ip = None
    for event in events:
        try:
            dt = datetime.fromisoformat(event['timestamp'].replace('Z', '+00:00'))
            time_key = dt.strftime('%H:%M:%S')
            
            # 记录切换触发时间
            if event.get('type') == 'failover_event':
                failover_time = time_key
                time_groups[time_key]['main'] = '🔄 触发Aurora集群切换'
            
            # 记录第一次错误时间
            elif 'error' in event and not first_error_time:
                first_error_time = time_key
                time_groups[time_key]['main'] = '⚠️ 开始出现连接问题'
            
            # 记录只读模式开始时间
            elif 'read-only mode' in event.get('error', '') and not readonly_start_time:
                readonly_start_time = time_key
                time_groups[time_key]['main'] = '📖 进入只读模式'
            
            # 记录DNS切换时间
            elif event.get('type') == 'dns' and event.get('status') == 'dns_success':
                ips = event.get('resolved_ips', [])
                current_ip = ips[2] if len(ips) > 2 else None
                if prev_ip and current_ip and prev_ip != current_ip:
                    dns_switch_time = time_key
                    time_groups[time_key]['main'] = '🔀 DNS切换完成'
                prev_ip = current_ip
            
            # 记录恢复时间（第一次写成功）
            elif (event.get('type') == 'mysql_write' and 
                  event.get('status') == 'write_success' and 
                  not recovery_time and 
                  readonly_start_time):
                recovery_time = time_key
                time_groups[time_key]['main'] = '✅ 写操作完全恢复'
            
            # 处理DNS事件
            if event.get('type') == 'dns':
                if event.get('status') == 'dns_success':
                    ips = event.get('resolved_ips', [])
                    # 提取实际IP地址（第三个元素）
                    ip_info = ips[2] if len(ips) > 2 else 'N/A'
                    # 提取主机名（第一个元素，去掉末尾的点）
                    hostname = ips[0].rstrip('.') if len(ips) > 0 else 'N/A'
                    # 简化主机名显示
                    if 'reader' in hostname:
                        host_short = 'reader'
                    elif 'instance' in hostname:
                        host_short = 'instance'
                    else:
                        host_short = hostname.split('.')[0]
                    
                    # 检查IP是否发生变化
                    current_ip = ips[2] if len(ips) > 2 else None
                    if prev_ip and current_ip and prev_ip != current_ip:
                        time_groups[time_key]['dns'] = f'🔀 DNS切换: {host_short} ({ip_info})'
                        if not dns_switch_time:  # 只记录第一次切换
                            dns_switch_time = time_key
                            time_groups[time_key]['main'] = '🔀 DNS切换完成'
                    else:
                        time_groups[time_key]['dns'] = f'✅ DNS解析成功 ({host_short}: {ip_info})'
                    prev_ip = current_ip
                else:
                    time_groups[time_key]['dns'] = '❌ DNS解析失败'
            
            # 处理MySQL读事件
            elif event.get('type') == 'mysql_read':
                if event.get('status') == 'read_success':
                    latency = event.get('elapsed_ms', 0)
                    time_groups[time_key]['read'] = f'✅ 读成功 ({latency:.1f}ms)'
                else:
                    error = event.get('error', '')
                    if 'Connection refused' in error:
                        time_groups[time_key]['read'] = '❌ 连接拒绝'
                    elif 'Connection reset' in error:
                        time_groups[time_key]['read'] = '❌ 连接重置'
                    else:
                        time_groups[time_key]['read'] = '❌ 读失败'
            
            # 处理MySQL写事件
            elif event.get('type') == 'mysql_write':
                if event.get('status') == 'write_success':
                    latency = event.get('elapsed_ms', 0)
                    time_groups[time_key]['write'] = f'✅ 写成功 ({latency:.1f}ms)'
                else:
                    error = event.get('error', '')
                    if 'read-only mode' in error:
                        time_groups[time_key]['write'] = '⚠️ 只读模式'
                    elif 'Connection refused' in error:
                        time_groups[time_key]['write'] = '❌ 连接拒绝'
                    else:
                        time_groups[time_key]['write'] = '❌ 写失败'
        except:
            continue
    
    return sorted(time_groups.items())

def generate_html_report(jsonl_file):
    """生成标准HTML报告"""
    events = load_jsonl_data(jsonl_file)
    analysis = analyze_test_data(events)
    chart_data = generate_chart_data(events)
    table_data = generate_event_table_data(events)
    
    # 格式化时间
    try:
        start_dt = datetime.fromisoformat(analysis['start_time'].replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(analysis['end_time'].replace('Z', '+00:00'))
        start_str = start_dt.strftime('%Y-%m-%d %H:%M:%S')
        end_str = end_dt.strftime('%H:%M:%S')
        
        if analysis['failover_time']:
            failover_dt = datetime.fromisoformat(analysis['failover_time'].replace('Z', '+00:00'))
            failover_str = failover_dt.strftime('%H:%M:%S')
        else:
            failover_str = "未检测到"
    except:
        start_str = end_str = failover_str = "解析失败"
    
    # 准备标记线数据
    mark_lines = []
    if analysis['failover_time_str']:
        mark_lines.append({
            'name': '切换触发',
            'xAxis': analysis['failover_time_str'],
            'lineStyle': {'color': '#f39c12', 'width': 2, 'type': 'dashed'},
            'label': {
                'show': True,
                'position': 'insideEndTop',
                'formatter': '切换触发',
                'color': '#f39c12',
                'fontSize': 12,
                'fontWeight': 'bold'
            }
        })
    if analysis['dns_switch_time_str']:
        mark_lines.append({
            'name': 'DNS切换',
            'xAxis': analysis['dns_switch_time_str'],
            'lineStyle': {'color': '#9b59b6', 'width': 2, 'type': 'dashed'},
            'label': {
                'show': True,
                'position': 'insideEndTop',
                'formatter': 'DNS切换',
                'color': '#9b59b6',
                'fontSize': 12,
                'fontWeight': 'bold'
            }
        })
    
    html_content = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aurora切换监控分析报告</title>
    <script src="https://unpkg.com/echarts@5.4.3/dist/echarts.min.js"></script>
    <style>
        body {{
            font-family: 'Microsoft YaHei', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #2c3e50;
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px solid #3498db;
            padding-bottom: 15px;
        }}
        h2 {{
            color: #34495e;
            margin-top: 40px;
            margin-bottom: 20px;
        }}
        .summary {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
        }}
        .summary h3 {{
            margin-top: 0;
            font-size: 24px;
        }}
        .summary-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }}
        .summary-section h4 {{
            margin-bottom: 10px;
            font-size: 16px;
        }}
        .summary-section ul {{
            margin: 0;
            padding-left: 20px;
        }}
        .metrics {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }}
        .metric {{
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }}
        .metric-value {{
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
        }}
        .metric-label {{
            font-size: 14px;
            opacity: 0.9;
        }}
        .chart-container {{
            width: 100%;
            height: 300px;
            margin: 20px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            background: #fafafa;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }}
        th {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: bold;
        }}
        tr:nth-child(even) {{
            background-color: #f8f9fa;
        }}
        tr:hover {{
            background-color: #e3f2fd;
        }}
        .table-container {{
            max-height: 500px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }}
        .loading {{
            text-align: center;
            padding: 50px;
            color: #666;
            font-size: 16px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🔄 Aurora切换监控分析报告</h1>
        
        <div class="summary">
            <h3>📊 测试概览</h3>
            <p><strong>测试时间:</strong> {start_str} - {end_str} ({analysis['duration']}秒) | <strong>集群:</strong> aurora-test-singapore | <strong>总记录数:</strong> {analysis['total_events']}条</p>
            
            <div class="summary-grid">
                <div class="summary-section">
                    <h4>🏗️ 测试环境</h4>
                    <ul>
                        <li>区域: 新加坡 (ap-southeast-1)</li>
                        <li>堡垒机: EC2实例 (ARM64)</li>
                        <li>Aurora集群: 2个实例</li>
                        <li>网络: 同AZ部署，减少网络延迟</li>
                    </ul>
                </div>
                
                <div class="summary-section">
                    <h4>🔍 探针设计</h4>
                    <ul>
                        <li>MySQL读: SELECT查询心跳表</li>
                        <li>MySQL写: INSERT心跳记录+COMMIT</li>
                        <li>DNS解析: dig cluster endpoint</li>
                        <li>监控间隔: 500ms高频采样</li>
                    </ul>
                </div>
                
                <div class="summary-section">
                    <h4>⏱️ 超时设置</h4>
                    <ul>
                        <li>MySQL读基线: 50ms (超时100ms)</li>
                        <li>MySQL写基线: 100ms (超时200ms)</li>
                        <li>DNS基线: 100ms (超时200ms)</li>
                        <li>连接超时: 读1秒，写2秒</li>
                    </ul>
                </div>
                
                <div class="summary-section">
                    <h4>🔄 测试过程</h4>
                    <ul>
                        <li>预热30秒: 建立性能基线</li>
                        <li>触发切换: 自动failover命令</li>
                        <li>监控60秒: 捕获完整切换过程</li>
                        <li>自动停止: 生成分析报告</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="metrics">
            <div class="metric">
                <div class="metric-value">{analysis['total_outage']}秒</div>
                <div class="metric-label">总切换时间</div>
            </div>
            <div class="metric">
                <div class="metric-value">{analysis['read_outage']}秒</div>
                <div class="metric-label">读操作中断</div>
            </div>
            <div class="metric">
                <div class="metric-value">{analysis['write_outage']}秒</div>
                <div class="metric-label">写操作中断</div>
            </div>
            <div class="metric">
                <div class="metric-value">瞬时</div>
                <div class="metric-label">DNS切换时间</div>
            </div>
        </div>

        <h2>📈 时间序列分析</h2>
        <div id="timeSeriesChart" class="chart-container">
            <div class="loading">正在加载图表...</div>
        </div>

        <h2>📋 详细事件日志</h2>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>时间戳</th>
                        <th>主线操作</th>
                        <th>DNS探针 & IP</th>
                        <th>MySQL读探针</th>
                        <th>MySQL写探针</th>
                    </tr>
                </thead>
                <tbody>'''
    
    # 添加表格数据
    for time_str, data in table_data:  # 显示所有数据
        html_content += f'''
                    <tr>
                        <td>{time_str}</td>
                        <td>{data['main']}</td>
                        <td>{data['dns']}</td>
                        <td>{data['read']}</td>
                        <td>{data['write']}</td>
                    </tr>'''
    
    html_content += f'''
                </tbody>
            </table>
        </div>
        
        <div style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 10px; border-left: 4px solid #3498db;">
            <h3 style="color: #2c3e50; margin-top: 0;">💡 关键发现</h3>
            <ul style="color: #34495e;">
                <li><strong>切换触发时间:</strong> {failover_str}</li>
                <li><strong>中断模式:</strong> 连接拒绝 → 只读模式 → 完全恢复</li>
                <li><strong>性能提升:</strong> 切换后读写延迟显著降低</li>
                <li><strong>DNS切换:</strong> 与服务恢复同步完成</li>
                <li><strong>应用层影响:</strong> 需要处理{analysis['write_outage']}秒的写操作不可用窗口</li>
            </ul>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {{
            setTimeout(function() {{
                if (typeof echarts === 'undefined') {{
                    document.getElementById('timeSeriesChart').innerHTML = 
                        '<div style="text-align:center;padding:50px;color:#e74c3c;font-size:16px;">' +
                        '⚠️ ECharts加载失败<br><small>请检查网络连接或刷新页面重试</small></div>';
                    return;
                }}
                initChart();
            }}, 1000);
        }});

        function initChart() {{
            const chart = echarts.init(document.getElementById('timeSeriesChart'));
            
            const chartData = {json.dumps(chart_data)};
            
            const option = {{
                title: {{
                    text: 'Aurora切换过程时间线',
                    left: 'center'
                }},
                tooltip: {{
                    trigger: 'axis'
                }},
                legend: {{
                    data: ['DNS状态', 'MySQL读状态', 'MySQL写状态'],
                    top: 30
                }},
                xAxis: {{
                    type: 'category',
                    data: chartData.times,
                    axisLabel: {{
                        rotate: 45
                    }}
                }},
                yAxis: {{
                    type: 'value',
                    name: '状态 (1=成功, 0=失败)',
                    min: 0,
                    max: 1,
                    interval: 1,
                    axisLabel: {{
                        formatter: function(value) {{
                            return value === 1 ? '成功' : '失败';
                        }}
                    }}
                }},
                series: [
                    {{
                        name: 'DNS状态',
                        type: 'line',
                        data: chartData.dnsStatus,
                        connectNulls: false,
                        smooth: true,
                        lineStyle: {{ color: '#3498db', width: 2 }},
                        itemStyle: {{ color: '#3498db' }},
                        symbol: 'circle',
                        symbolSize: 4,
                        markLine: {{
                            data: {json.dumps(mark_lines)}
                        }}
                    }},
                    {{
                        name: 'MySQL读状态',
                        type: 'line',
                        data: chartData.readStatus,
                        connectNulls: false,
                        smooth: true,
                        lineStyle: {{ color: '#27ae60', width: 2 }},
                        itemStyle: {{ color: '#27ae60' }},
                        symbol: 'circle',
                        symbolSize: 4
                    }},
                    {{
                        name: 'MySQL写状态',
                        type: 'line',
                        data: chartData.writeStatus,
                        connectNulls: false,
                        smooth: true,
                        lineStyle: {{ color: '#e74c3c', width: 2 }},
                        itemStyle: {{ color: '#e74c3c' }},
                        symbol: 'circle',
                        symbolSize: 4
                    }}
                ]
            }};
            
            chart.setOption(option);
            
            window.addEventListener('resize', function() {{
                chart.resize();
            }});
        }}
    </script>
</body>
</html>'''
    
    # 保存HTML文件
    output_file = f"{jsonl_file.replace('.jsonl', '')}_standard_report.html"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"标准HTML报告已生成: {output_file}")
    return output_file

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("用法: python3 generate_standard_report.py <jsonl_file>")
        sys.exit(1)
    
    generate_html_report(sys.argv[1])
